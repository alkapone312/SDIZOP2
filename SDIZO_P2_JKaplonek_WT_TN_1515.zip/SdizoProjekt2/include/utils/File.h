#pragma once

namespace SDIZO {
    class File {
        public:
            static bool fileExists(std::string filename);
    };
}