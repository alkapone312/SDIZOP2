# Projekt Struktury Danych i Złożoność Obliczeniowa

## Kompilacja
```
make
```

## Uruchomienie
```
./bin/main
```